package watch.aspect;

public interface Validatable {
    void validate();
}
