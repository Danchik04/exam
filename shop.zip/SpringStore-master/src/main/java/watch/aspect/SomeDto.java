package watch.aspect;

public class SomeDto implements Validatable {
    private String name;
    private int age;

    @Override
    public void validate() {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
    }
}
